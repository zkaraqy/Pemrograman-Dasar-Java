
package uts;

public class MuhammadAzkaRaki2311016110005Soal1 {

    public static void main(String args[]) {
        
    }
}
